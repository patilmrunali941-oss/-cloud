# BrightPath Website

A responsive Flask website with Home, About, Services, and Contact sections.

## Run locally
```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:8080

## Deploy to Google Cloud Run
1. Install Google Cloud CLI and sign in: `gcloud auth login`
2. Select your project: `gcloud config set project YOUR_PROJECT_ID`
3. Enable billing for the project and enable required APIs:
   `gcloud services enable run.googleapis.com cloudbuild.googleapis.com`
4. From this folder deploy:
   `gcloud run deploy brightpath-website --source . --region asia-south1 --allow-unauthenticated`
5. Confirm the prompts. Cloud Run prints your public HTTPS URL.

The contact form currently displays a confirmation only; it does not email or store messages. Replace the demo secret key before production and connect an email provider/database if needed.
