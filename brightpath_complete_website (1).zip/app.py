from flask import Flask, render_template, request, flash, redirect, url_for

app = Flask(__name__)
app.secret_key = "replace-this-with-a-random-secret"

@app.route("/", methods=["GET", "POST"])
def home():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip()
        message = request.form.get("message", "").strip()
        if name and email and message:
            # Demo contact form: displays confirmation; connect an email/database for storage.
            flash(f"Thanks, {name}! Your message has been received.", "success")
            return redirect(url_for("home") + "#contact")
        flash("Please complete all fields.", "error")
    return render_template("index.html")

@app.route("/health")
def health():
    return {"status": "ok"}

if __name__ == "__main__":
    import os
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8080)), debug=False)
